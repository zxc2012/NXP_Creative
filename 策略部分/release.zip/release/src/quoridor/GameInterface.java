package quoridor;

/**
 * GameInterface for generic calling of all game subtypes
 */
public interface GameInterface   {

	public boolean playGame();
	
}