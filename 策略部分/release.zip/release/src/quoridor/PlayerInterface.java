package quoridor;



/**
 * @author Stump
 * Contains all the information that is relevant to a player. 
 * Thus being - Their name, their token as to be displayed on the board and their current space. 
 */
public interface PlayerInterface {

/////Add anything methods that you feel should be here
}
